package POM;

import Elements.Table;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class W3school extends POM{

    public W3school(WebDriver driver){
        super(driver);
    }
    public Table getCompaniesTable(){
        return new Table("customers",driver);
    }

    public String getTableCellText(WebElement table, int searchColumn, String searchText, int returnColumnText) {
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row : rows) {
            List<WebElement> cells = row.findElements(By.tagName("td"));
            if (cells.size() > searchColumn && cells.get(searchColumn).getText().equals(searchText)) {
                return cells.get(returnColumnText).getText();
            }
        }
        return null;
    }

    public boolean verifyTableCellText(WebElement table, int searchColumn, String searchText, int returnColumnText, String expectedText) {
        String actualText = getTableCellText(table, searchColumn, searchText, returnColumnText);
        return expectedText.equals(actualText);
    }


    public String getTableCellTextByXpath(WebElement table, int searchColumn, String searchText, int returnColumnText) throws Exception {
        String xpathExpression = String.format("//tr[td[%d] = '%s']/td[%d]", searchColumn + 1, searchText, returnColumnText + 1);
        WebElement cell = table.findElement(By.xpath(xpathExpression));
        return cell.getText();
    }

    public boolean verifyTableCellTextByXpath(WebElement table, int searchColumn, String searchText, int returnColumnText, String expectedText) throws Exception {
        String actualText = getTableCellTextByXpath(table, searchColumn, searchText, returnColumnText);
        return expectedText.equals(actualText);
    }

}
