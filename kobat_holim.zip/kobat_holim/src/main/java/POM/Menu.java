package POM;

import hooks.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Menu extends POM {
    public Menu(WebDriver driver) {
        super(driver);
    }

    public void selectMenuItem(String menuInfo) {
        String[] items = menuInfo.split(";");
        WebElement mainMenu = Hooks.getDriver().findElement(By.xpath("//ul[@class='nav navbar-nav']/li[contains(@class, 'dropdown')]/a[contains(text(), '" + items[0] + "')]"));
        mainMenu.click();
        if (items.length > 1) {
            WebElement subMenu = Hooks.getDriver().findElement(By.linkText(items[1]));
            subMenu.click();
        }
    }

    public void selectMenu(String mainMenuText, String subMenuText) {
        selectMenuItem(mainMenuText + ";" + subMenuText);
    }
}
