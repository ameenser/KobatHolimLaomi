package stepdefinitions;

import POM.Menu;
import Elements.Table;
import POM.W3school;
import hooks.Hooks;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.csv.CSVFormat;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

public class MyFeatureStepDefs {
    @When("^UI Verify Table Cell Text by \"(.*)\"$")
    public void UI_Verify_Table_Cell_text(String verifyBy) throws Exception {
        W3school w3 = new W3school(Hooks.getDriver());
        Table companiesTable = w3.getCompaniesTable();
        Iterable<CSVRecord> records = loadCSVFromResource();
        Iterator<CSVRecord> iterator = records.iterator();
        if (iterator.hasNext()) {
            CSVRecord record = iterator.next();
            // Read values from CSV
            int searchColumn = Integer.parseInt(record.get("SearchColumn"));
            String searchText = record.get("SearchText");
            int returnColumn = Integer.parseInt(record.get("ReturnColumnText"));
            String expectedText = record.get("Expected");
            if(verifyBy.equals("for")){
                if (!w3.verifyTableCellText(companiesTable.table, searchColumn, searchText, returnColumn, expectedText)) {
                    throw new AssertionError("Expected text not equal to the actual text in the table cell.");
                }
            }
            else if(verifyBy.equals("xpath")){
                if (!w3.verifyTableCellTextByXpath(companiesTable.table, searchColumn, searchText, returnColumn, expectedText)) {
                    throw new AssertionError("Expected text not equal to the actual text in the table cell.");
                }
            }


        } else {
            throw new AssertionError("No CSV records found.");
        }
    }

    @Then("UI Select from Main Menu \"(.*)\" and Sub Menu \"(.*)\"$")
    public void uiSelectFromMainMenuAndSubMenu(String mainMenu, String subMenu) {
        Menu m = new Menu(Hooks.getDriver());
        m.selectMenu(mainMenu,subMenu);
    }


    public static Iterable<CSVRecord> loadCSVFromResource() {
        // Using try-with-resources to ensure proper closure of streams
        try (InputStream is = MyFeatureStepDefs.class.getClassLoader().getResourceAsStream("data.csv");
             InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            if (is == null) {
                throw new IllegalArgumentException("file not found! data.csv");
            }
            Iterable<CSVRecord> records = CSVFormat.DEFAULT.withFirstRecordAsHeader().parse(isr);
            return records;
        } catch (Exception e) {
            System.err.println("Error processing the CSV file: " + e.getMessage());
            e.printStackTrace();
        }
        return  null;
    }
}