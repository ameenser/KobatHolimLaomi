package Elements;

import hooks.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Table extends Element{

    public WebElement table;

    public Table(String selector, WebDriver driver) {
        super(selector, driver);
        table = Hooks.getDriver().findElement(By.id(selector));

    }

}
